DROP TABLE IF EXISTS public.tweet;

CREATE TABLE IF NOT EXISTS public.tweet (
	created_at timestamp NOT NULL,
	tweet_id numeric(30,0),
	tweet nvarchar(max),
	likes integer,
	retweet_count integer,
    source nvarchar(255),
    CONSTRAINT tweet_pkey PRIMARY KEY (created_at)
);

DROP TABLE IF EXISTS public.user;

CREATE TABLE IF NOT EXISTS public.user (
	user_id numeric(30,0) NOT NULL,
	user_name nvarchar(255) ,
	user_screen_name nvarchar(255),
	user_description nvarchar(max),
	user_join_date timestamp,
	user_followers_count integer,
    CONSTRAINT user_pkey PRIMARY KEY (user_id)
);

DROP TABLE IF EXISTS public.geo_location;

CREATE TABLE IF NOT EXISTS public.geo_location (
	lat numeric(20,10) NOT NULL,
	long numeric(20,10) NOT NULL,
	user_location nvarchar(255),
	city nvarchar(255),
	country nvarchar(255),
	continent nvarchar(255),
    state nvarchar(255),
    state_code nvarchar(255),
    CONSTRAINT geo_location_pkey PRIMARY KEY (lat,long)
);

DROP TABLE IF EXISTS public.staging_biden;

CREATE TABLE IF NOT EXISTS public.staging_biden (
	created_at nvarchar(255),
	tweet_id nvarchar(255),
	tweet nvarchar(max),
	likes nvarchar(255),
	retweet_count nvarchar(255),
    source nvarchar(255),
    user_id nvarchar(255),
	user_name nvarchar(255) ,
	user_screen_name nvarchar(255),
	user_description nvarchar(max),
	user_join_date nvarchar(255),
	user_followers_count nvarchar(255),
	user_location nvarchar(255),
	lat nvarchar(255),
	long nvarchar(255),
	city nvarchar(255),
	country nvarchar(255),
	continent nvarchar(255),
    state nvarchar(255),
    state_code nvarchar(255),
    collected_at nvarchar(255)
    
);
DROP TABLE IF EXISTS public.staging_trump;

CREATE TABLE IF NOT EXISTS public.staging_trump (
	created_at nvarchar(255),
	tweet_id nvarchar(255),
	tweet nvarchar(max),
	likes nvarchar(255),
	retweet_count nvarchar(255),
    source nvarchar(255),
    user_id nvarchar(255),
	user_name nvarchar(255) ,
	user_screen_name nvarchar(255),
	user_description nvarchar(max),
	user_join_date nvarchar(255),
	user_followers_count nvarchar(255),
	user_location nvarchar(255),
	lat nvarchar(255),
	long nvarchar(255),
	city nvarchar(255),
	country nvarchar(255),
	continent nvarchar(255),
    state nvarchar(255),
    state_code nvarchar(255),
    collected_at nvarchar(255)
);

DROP TABLE IF EXISTS public.tweet_fact;

CREATE TABLE IF NOT EXISTS public.tweet_fact (
	factid INT GENERATED ALWAYS AS IDENTITY,
	created_at timestamp NOT NULL,
	user_id numeric(30,0) NOT NULL,
	lat numeric(20,10) NOT NULL,
	long numeric(20,10) NOT NULL,
	user_name nvarchar(255),
	tweet nvarchar(max),
    CONSTRAINT tweet_fact_pkey PRIMARY KEY (factid)
);





