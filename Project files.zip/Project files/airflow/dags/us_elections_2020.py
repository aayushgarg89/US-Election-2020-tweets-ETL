from datetime import datetime, timedelta
import os
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators import (StageToRedshiftOperator, LoadFactOperator,
                                LoadDimensionOperator, DataQualityOperator)
from airflow.operators.postgres_operator import PostgresOperator
from helpers import SqlQueries


default_args = {
    'owner': 'udacity',
    'depends_on_past':False,
    'start_date': datetime(2020,1,1),
    'retries':3,
    'retry_delay':timedelta(minutes=3),
    'catchup':False,
    'email_on_retry':False,
}

dag = DAG('us_elections_2020',
          default_args=default_args,
          description='Load and transform data in Redshift with Airflow'
          schedule_interval='0 1 * * *'
        )

start_operator = DummyOperator(task_id='Begin_execution',  dag=dag)

create_tables_task = PostgresOperator(
    task_id="create_stage_fact_dimension_table_if_not_exists",
    dag=dag,
    sql='create_tables.sql',
    postgres_conn_id="redshift"
)
   
stage_biden_to_redshift = StageToRedshiftOperator(
    task_id='Stage_biden',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    table="public.staging_biden",
    s3_bucket="udacity-capstone-project-us-elections-2020",
    s3_key="hashtag_biden"
    
)

stage_trump_to_redshift = StageToRedshiftOperator(
    task_id='Stage_trump',
    dag=dag,
    redshift_conn_id="redshift",
    aws_credentials_id="aws_credentials",
    table="public.staging_trump",
    s3_bucket="udacity-capstone-project-us-elections-2020",
    s3_key="hashtag_trump"
)

load_tweet_fact_table = LoadFactOperator(
    task_id='Load_tweet_fact_table',
    dag=dag,
    redshift_conn_id="redshift",
    sql_statement=SqlQueries.tweet_fact_table_insert,
    table="public.tweet_fact",
    append_data="True"
    
)

load_tweet_dimension_table = LoadDimensionOperator(
    task_id='Load_tweet_dim_table',
    dag=dag,
    redshift_conn_id="redshift",
    sql_statement=SqlQueries.tweet_table_insert,
    table="public.tweet",
    append_data="True"
)

load_user_dimension_table = LoadDimensionOperator(
    task_id='Load_user_dim_table',
    dag=dag,
    redshift_conn_id="redshift",
    sql_statement=SqlQueries.user_table_insert,
    table="public.user",
    append_data="True"
)

load_geo_location_dimension_table = LoadDimensionOperator(
    task_id='Load_geo_location_dim_table',
    dag=dag,
    redshift_conn_id="redshift",
    sql_statement=SqlQueries.geo_location_table_insert,
    table="public.geo_location",
    append_data="True"
)

run_quality_checks = DataQualityOperator(
    task_id='Run_data_quality_checks',
    dag=dag,
    tables=['public.tweet','public.user','public.geo_location','public.staging_biden','public.staging_trump','public.tweet_fact'],
    redshift_conn_id="redshift"
)

end_operator = DummyOperator(task_id='Stop_execution',  dag=dag)

start_operator >> create_tables_task
create_tables_task >> [stage_biden_to_redshift, stage_trump_to_redshift]
stage_biden_to_redshift >> load_tweet_fact_table
stage_trump_to_redshift >> load_tweet_fact_table
load_tweet_fact_table >> [load_tweet_dimension_table, load_user_dimension_table, load_geo_location_dimension_table] 
load_tweet_dimension_table >> run_quality_checks
load_user_dimension_table >> run_quality_checks
load_geo_location_dimension_table >> run_quality_checks
run_quality_checks >> end_operator

