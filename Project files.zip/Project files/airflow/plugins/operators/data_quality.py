import logging
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 tables=[],
                 redshift_conn_id="",
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.tables=tables
        self.redshift_conn_id=redshift_conn_id

    def execute(self, context):
        redshift_hook=PostgresHook(self.redshift_conn_id)
        
        for table in self.tables:
            records=redshift_hook.get_records(f"SELECT COUNT (*) from {table}")
            if len(records) < 1 or len(records[0]) < 1 or records[0][0] < 1:
                raise ValueError(f"Data quality check failed. {table} returned no results")
            logging.info(f"Data quality on table {table} check passed with {records[0][0]} records")
        
        
        dq_checks=[
            {'check_sql':"SELECT COUNT(*) FROM public.user where user_id IS NULL ",'expected_result':0},
            {'check_sql':"SELECT COUNT(*) FROM public.tweet where created_at IS NULL ",'expected_result':0},
            {'check_sql':"SELECT COUNT(*) FROM public.geo_location where lat IS NULL OR long IS NULL ",'expected_result':0},
            {'check_sql':"SELECT COUNT(*) FROM public.tweet_fact where factid IS NULL ",'expected_result':0}
                    ]
        
        error_count=0
        failing_tests=[]
        for check in dq_checks:
            table_count=check.get('check_sql')
            exp_result=check.get('expected_result')
            
            records=redshift_hook.get_records(table_count)[0]
            
            if records[0]!=exp_result:
                error_count+=1
                failing_tests.append(table_count)
        
        if error_count >0:
            self.log.info('table count test failed')
            self.log.info(failing_tests)
            raise ValueError("Data Quality check failed")
        else:
            self.log.info("Data Quality check passed")
            