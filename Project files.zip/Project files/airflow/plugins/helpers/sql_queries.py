class SqlQueries:
    tweet_fact_table_insert = ("""
        (
        created_at,
        user_id,
        lat,
        long,
        user_name,
        tweet
        )
        SELECT
                CAST(created_at AS timestamp),
                CAST(user_id AS numeric(30,0)), 
                CAST(lat AS numeric(20,10)), 
                CAST(long AS numeric(20,10)), 
                user_name, 
                tweet
            FROM staging_biden
            UNION
        SELECT
                CAST(created_at AS timestamp),
                CAST(user_id AS numeric(30,0)), 
                CAST(lat AS numeric(20,10)), 
                CAST(long AS numeric(20,10)), 
                user_name, 
                tweet
            FROM staging_trump
    """)

    tweet_table_insert = ("""
        SELECT distinct 
                    CAST(created_at AS timestamp),
                    CAST(tweet_id AS numeric(30,0)), 
                    tweet, 
                    CAST(likes AS integer), 
                    CAST(retweet_count AS integer), 
                    source
        FROM staging_biden
        UNION
        SELECT distinct 
                    CAST(created_at AS timestamp),
                    CAST(tweet_id AS numeric(30,0)), 
                    tweet, 
                    CAST(likes AS integer), 
                    CAST(retweet_count AS integer), 
                    source
        FROM staging_trump
    """)

    user_table_insert = ("""
        SELECT distinct 
                    CAST(user_id AS numeric(30,0)), 
                    user_name, 
                    user_screen_name, 
                    user_description, 
                    CAST(user_join_date AS timestamp), 
                    CAST(user_followers_count AS integer) 
        FROM staging_biden
        UNION
        SELECT distinct 
                    CAST(user_id AS numeric(30,0)), 
                    user_name, 
                    user_screen_name, 
                    user_description, 
                    CAST(user_join_date AS timestamp), 
                    CAST(user_followers_count AS integer) 
        FROM staging_trump
    """)

    geo_location_table_insert = ("""
        SELECT distinct 
                    CAST(lat AS numeric(20,10)), 
                    CAST(long AS numeric(20,10)), 
                    user_location, 
                    city, 
                    country, 
                    continent, 
                    state, 
                    state_code
        FROM staging_biden
        UNION
        SELECT distinct 
                    CAST(lat AS numeric(20,10)), 
                    CAST(long AS numeric(20,10)), 
                    user_location, 
                    city, 
                    country, 
                    continent, 
                    state, 
                    state_code
        FROM staging_biden
    """)
