Data Engineering Capstone Project

### Step 1: Scope the Project and Gather Data

#### Scope 
The purpose of this project is to collect about 2 million tweets from Twitter APIs, explored using Spark, cleaned via pandas and copy the clean data to S3, orchestrated the data by building the conceptual star schema model in Redshift using Airflow DAGs and Plugin Operators and performed necessary data quality checks thereafter, to give to end users or data scientists for sentiment analysis of who will win 2020 US elections. 

#### Describe and Gather Data 
I have taken the dataset from Kaggle named US Elections 2020 Tweets that consists from about 1.72 Million Tweets in 2 csv files that are collected from various twitter APIs by screenscrapping the keywords "trump" and "biden" in the tweet text 

The project files consists of "US Elections 2020.ipynb" file that details out the steps that are required to perform STEP 2 and STEP 3 below

### Step 2: Explore and Assess the Data
#### Explore the Data 
Perfomed necessary steps using pandas as mentioned in US Elections 2020.ipynb

#### Cleaning Steps
Performed necessary steps using pandas as mentioned in US Elections 2020.ipynb


### Step 3: Define the Data Model
#### 3.1 Conceptual Data Model
Map out the conceptual data model and explain why you chose that model

I have created a star schema conceptual model in redshift which consists of the 1 fact table and 3 dimension table as it is easier to understand as opposed to creating multiple tables where we have to perform deep joins to get more information about the data. Plus the data is more performant in star schema.

Here is the structure of the star schema conceptual model:

Fact Table : 
            tweet_fact - It consists of the primary keys of the 3 dimension tables and the required fields to perform sentiment analysis
                        factid, created_at, user_id, usar_name, lat, long, tweet 
                        
Dimension Tables :
            user - users who tweeted from various twitter APIs
                    user_id, user_name, user_screen_name, user_description, user_join_date, user_followers_count
            tweet - details on each tweets collected
                    created_at, tweet_id, tweet, likes, retweet_count, source
            geo_location - details on demographics from where people tweeted
                    lat, long, user_location, city, country, continent, state, state_code 

#### 3.2 Mapping Out Data Pipelines
I have used the open source ETL tool called airflow that will copy the data from the files stored in S3 into various staging tables in redshift and then from those staging tables, the data is unioned together to create the fact table and multiple dimension tables and then the required quality checks are performed to ensure the validity of the data

### Step 4: Run Pipelines to Model the Data 
#### 4.1 Create the data model
The project file consists of the Airflow DAGs and plugins that consists of the necessary steps to create a data model in redshift
The Airflow dags consists of the 2 files:
		1. create_tables.sql - This file consists of DDL SQL scripts of 1 fact table, 3 dimension tables and 2 staging table
		2. us_elections_2020.py - this file uses multiple operators and define the flow of execution that is performed by airflow. 
The Airflow plugins consists of 2 folders
	1. Helpers folder consists of sql_queries.py file that defined the DML statements of inserting the data into fact and dimension tables from the staging tables
	2.Operators folder consits of 4 files:
		a. Stage_redshift.py - This file lists the steps of copy the data from S3 to redshift staging tables
		b. Load_dimensions.py - This file lists the steps on how the data is copied into dimension tables from the staging tables
		c. Load_fact.py - This file lists the steps on how the data is copied into fact table from the staging tables
		d. data_quality.py - This file includes all the data quality checks that is listed in STEP 4.2 below

#### 4.2 Data Quality Checks
Explain the data quality checks you'll perform to ensure the pipeline ran as expected. These could include:
 * Integrity constraints on the relational database (e.g., unique key, data type, etc.)
 * Unit tests for the scripts to ensure they are doing the right thing
 * Source/Count checks to ensure completeness
Run Quality Checks

#### 4.3 Data dictionary 

brief description of what the data is

created_at: Date and time of tweet creation
tweet_id: Unique ID of the tweet
tweet: Full tweet text
likes: Number of likes
retweet_count: Number of retweets
source: Utility used to post tweet
user_id: User ID of tweet creator
user_name: Username of tweet creator
user_screen_name: Screen name of tweet creator
user_description: Description of self by tweet creator
user_join_date: Join date of tweet creator
user_followers_count: Followers count on tweet creator
user_location: Location given on tweet creator's profile
lat: Latitude parsed from user_location
long: Longitude parsed from user_location
city: City parsed from user_location
country: Country parsed from user_location
state: State parsed from user_location
state_code: State code parsed from user_location
collected_at: Date and time tweet data was mined from twitter


#### Step 5: Complete Project Write Up
* Clearly state the rationale for the choice of tools and technologies for the project.
	Since the dataset consists of about 2 million rows so big data tools such as spark, python pandas are used to explore and clean the data, AWS tools and technologies such as S3 buckets to store that amount of data and Airflow to orchestrate the storing of this amount of data into AWS redshift into staging tables first and then fact and dimension tables in the form of star schema to present the clean data to end users or data scientist to perform sentiment analysis. 
* Propose how often the data should be updated and why.
	The aiflow pipeline runs everyday and loads the data into fact and dimension tables before 7 am in the morning.Since tweets are generated everyday, the system should capture the tweets every day by parsing on the keywords,perform necessary cleaning operations and store the data in the form of .csv files into respective S3 buckets. 1 Bucket for storing the tweets related to Donanld Trump and another bucket for storing the tweets related to Joe Binden. The staging plugin operator will pick all the files and store it in redshift staging tables and then in respective fact and dimensions tables.
* Write a description of how you would approach the problem differently under the following scenarios:
 * The data was increased by 100x.
	Will use S3 buckets to store the data as it provides infinite amount of storage and that to at a very low cost.Also we will be using EMR to explore,access and clean the data as opposed to the local instance of jupyter notebook.
 * The data populates a dashboard that must be updated on a daily basis by 7am every day.
	The airflow pipeline would run daily at 7 am that takes all the csv files from respective S3 buckets and updates the data in staging tables in redshift that is then picked up by fact and dimension tables in redshift.
 * The database needed to be accessed by 100+ people.
	We will give the read access to the dashboard that consists of upto date data everyday at around 8 AM in the morning and will also give only the read access to         query the data of fact and dimension tables in Redshift to avoid accidently update/delete anything if given both read and write access.